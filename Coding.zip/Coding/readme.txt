Problem 1:

A)Design and Implementation.

Allow user to specify the maximum range to generate the random numbers. It will generate from 0 to Maximum range user specified.

Developed a class Randomizer with two methods Randomizer and PrimeRandomizer as per the requirements given.

Randomizer method will return the list of 10 random numbers in the range specified.The Prime Randomizer will check for the Prime numbers in the list of random numbers passed by Randomizer method.

The PrimeRandomizer will return the list of Prime number and Non Prime numbers to Randomizer method.

B)Sample Output:
Enter maximum range 
10
Random Numbers in range:
5
6
9
8
7
Prime and Non Prime Numbers:
5 is prime number
6 is not a prime number
9 is not a prime number
8 is not a prime number
7 is a prime number

Further Implementation:
C)Generate all the random numbes in the range specified.Check all the Prime and Non Prime numbers in the range specified.As of now we I have considered 10 random number s in the range specified.
